Copyright (c) 1998-2003
John Maddock

 * Use, modification and distribution are subject to the 
 * Boost Software License, Version 1.0. (See accompanying file 
 * LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

************************************************************************

Full instructions for use of this library can be accessed from
libs/regex/docs/index.html

Installation instructions and library overview is are in
libs/regex/docs/introduction.html

This library is part of boost (see www.boost.org), the latest version 
of the library is available from the boost web site, or development
snapshots from the boost cvs repository at 
http://sourceforge.net/project/?group_id=7586


